import * as fs from 'fs';
import * as path from 'path';
import YAML from 'yaml';
import { Ticket, PromptContext } from './types';

type AnyObj = Record<string, any>;

type LoadedSpec = {
  prompt_id: string;
  description?: string;
  version?: number;
  vars?: Array<{ name: string; description?: string }>;
  constraints?: { language?: string; max_chars?: number; [k: string]: any };
  sections?: { system?: string };
  assistant_style?: string;
  user_template?: string;
  outputs?: AnyObj;
};

type CacheEntry = {
  file: string;
  mtime: number;
  byId: Map<string, LoadedSpec>;
  defaultId: string | null;
};

const cache: { reply: CacheEntry | null; triage: CacheEntry | null } = {
  reply: null,
  triage: null,
};

/* ───────────────────────────── Prompts 檔案載入 ───────────────────────────── */

function resolvePromptsDir(): string {
  const override = process.env.POB_PROMPTS_DIR;
  if (override) return override;
  const root = path.resolve(__dirname, '..'); // out/ → 專案根
  return path.join(root, 'src', 'prompts');
}

function readYamlFileStrict(filePath: string): any {
  if (!fs.existsSync(filePath)) {
    throw new Error(`[promptBuilder] spec file not found: ${filePath}`);
  }
  const raw = fs.readFileSync(filePath, 'utf8');
  try {
    return YAML.parse(raw);
  } catch (e: any) {
    throw new Error(`[promptBuilder] YAML parse error @ ${filePath}: ${e?.message || e}`);
  }
}

/** 取得對應 kind 的檔案路徑 */
function getSpecFile(kind: 'reply' | 'triage'): string {
  const dir = resolvePromptsDir();
  return path.join(dir, kind === 'reply' ? 'reply.yaml' : 'triage.yaml');
}

/** 檢查快取是否仍新鮮 */
function isCacheFresh(
  c: CacheEntry | null,
  file: string,
  mtime: number
): c is CacheEntry {
  return !!c && c.file === file && c.mtime === mtime;
}

/** 將 YAML 內容轉成規範化的 LoadedSpec 陣列 */
function normalizeSpecs(parsed: any, file: string): LoadedSpec[] {
  let specs: any[] = [];
  if (Array.isArray(parsed)) specs = parsed;
  else if (parsed?.prompts && Array.isArray(parsed.prompts)) specs = parsed.prompts;
  else if (parsed?.prompt_id) specs = [parsed];
  else throw new Error(`[promptBuilder] No valid prompt spec in ${file}`);

  return specs.map((s) => {
    if (!s || typeof s !== 'object' || typeof s.prompt_id !== 'string') {
      throw new Error(`[promptBuilder] spec missing prompt_id in ${file}`);
    }
    return s as LoadedSpec;
  });
}

/** 由 specs 建立快取條目 */
function buildCacheEntry(
  file: string,
  mtime: number,
  specs: LoadedSpec[]
): CacheEntry {
  const byId = new Map<string, LoadedSpec>();
  let first: string | null = null;
  for (const s of specs) {
    if (!first) first = s.prompt_id;
    byId.set(s.prompt_id, s);
  }
  return { file, mtime, byId, defaultId: first };
}

/** 降複雜度後的 loadSpec：小步切分、早回傳 */
function loadSpec(kind: 'reply' | 'triage'): CacheEntry {
  const file = getSpecFile(kind);
  const mtime = fs.statSync(file).mtimeMs;

  const c = cache[kind];
  if (isCacheFresh(c, file, mtime)) return c!;

  const parsed = readYamlFileStrict(file);
  const specs = normalizeSpecs(parsed, file);
  const entry = buildCacheEntry(file, mtime, specs);
  cache[kind] = entry;
  return entry;
}

function pickSpec(kind: 'reply' | 'triage', preferredId?: string): LoadedSpec {
  const entry = loadSpec(kind);
  const id = preferredId && entry.byId.has(preferredId) ? preferredId : entry.defaultId;
  if (!id) throw new Error(`[promptBuilder] No ${kind} prompt_id resolvable`);
  return entry.byId.get(id)!;
}

/* ─────────────────────────── 迷你樣板（降複雜度） ─────────────────────────── */

function resolveVar(scope: AnyObj, key: string): any {
  return key.split('.').reduce((o: any, p: string) => (o != null ? o[p] : undefined), scope);
}
function renderVarsOnce(tpl: string, scope: AnyObj): string {
  return tpl.replace(/{{\s*([\w.]+)\s*}}/g, (_m: string, k: string) => {
    const val = resolveVar(scope, k);
    return val == null ? '' : String(val);
  });
}
function renderLoops(tpl: string, scope: AnyObj): string {
  return tpl.replace(
    /{%\s*for\s+(\w+)\s+in\s+(\w+)\s*%}([\s\S]*?){%\s*endfor\s*%}/g,
    (_m: string, itVar: string, listVar: string, body: string) => {
      const list = Array.isArray(scope[listVar]) ? scope[listVar] : [];
      return list
        .map((item: any, idx: number) => {
          const local = { ...scope, [itVar]: item, idx };
          return renderVarsOnce(renderLoops(body, local), local);
        })
        .join('');
    }
  );
}
function render(tpl: string, vars: AnyObj): string {
  return renderVarsOnce(renderLoops(tpl, vars), vars);
}

/* ─────────────────────────────── 共用小工具 ─────────────────────────────── */

function stripFences(raw: string): string {
  const text = (raw || '').trim();
  const m = text.match(/```json([\s\S]*?)```/i) || text.match(/```([\s\S]*?)```/i);
  return m ? m[1].trim() : text;
}
function safeParseJson(text: string): { ok: true; value: any } | { ok: false; error: string } {
  try {
    return { ok: true, value: JSON.parse(text) };
  } catch {
    return { ok: false, error: 'JSON 解析失敗' };
  }
}
function expectArrayOfStrings(v: any, field: string, errors: string[]) {
  if (v === undefined) return;
  if (!Array.isArray(v) || !v.every(x => typeof x === 'string')) {
    errors.push(`${field} 必須為字串陣列`);
  }
}
function expectCitations(v: any, errors: string[]) {
  if (v === undefined) return;
  if (!Array.isArray(v)) return errors.push('citations 必須為陣列');
  for (const c of v) {
    if (!c || typeof c !== 'object' || typeof c.label !== 'string' || typeof c.url !== 'string') {
      errors.push('citations 需要 {label,url}');
      break;
    }
  }
}
function clampMaxChars(n: unknown, fallback: number): number {
  const x = Number(n);
  return Number.isFinite(x) && x > 0 ? Math.floor(x) : fallback;
}

/* ─────────────────────────────── 主類：精簡版 ─────────────────────────────── */

/** 非目標票據 → 由上游標記 failed，不再 fallback */
export class UnsupportedTicketKindError extends Error {
  constructor(message = 'Unsupported ticket kind') {
    super(message);
    this.name = 'UnsupportedTicketKindError';
  }
}

export class PromptBuilder {
  private static readonly DEFAULT_MAX_CHARS = 500;
  private static readonly PROMPT_OVERHEAD = 300;

  /** 僅支援 REPLY / TRIAGE，其他直接丟錯 */
  static buildPrompt(ticket: Ticket): string {
    if (isReplyTicket(ticket))  return this.buildReplyFromYaml(ticket);
    if (isTriageTicket(ticket)) return this.buildTriageFromYaml(ticket);
    throw new UnsupportedTicketKindError(
      `Unsupported ticket kind (flow_id=${ticket.flow_id}, event=${ticket.event?.type})`
    );
  }

  /** 供 TicketWorker 呼叫的公開方法（與舊名相容） */
  static buildReplyPrompt(ticket: Ticket): string {
    return this.buildReplyFromYaml(ticket);
  }

  /* ---------- YAML 建構：統一一條路，再由參數微調 ---------- */

  private static buildFromYamlUnified(
    kind: 'reply' | 'triage',
    ticket: Ticket,
    preferredId?: string,
    extraVars: AnyObj = {}
  ): string {
    const spec = pickSpec(kind, preferredId);
    const system = (spec.sections?.system || '').trim();
    const assistant = (spec.assistant_style || '').trim();
    const user = render(spec.user_template || '', extraVars).trim();

    const maxChars =
      spec.constraints?.max_chars ??
      (ticket.constraints?.max_chars ?? PromptBuilder.DEFAULT_MAX_CHARS);
    const lang = spec.constraints?.language || ticket.constraints?.lang || 'zh-Hant';
    const jsonHint =
      kind === 'reply'
        ? `（請只輸出符合 spec.outputs.schema 的 JSON；語言=${lang}；長度 ≤ ${maxChars}）`
        : `（請只輸出符合 spec.outputs.schema 的 JSON）`;

    return [system, assistant, user, jsonHint].filter(Boolean).join('\n\n');
  }

  private static buildReplyFromYaml(ticket: Ticket): string {
    const replyInput = ticket.metadata.reply_input || {};
    const triageResult = ticket.metadata.triage_result || {};
    const vars = {
      stance_summary: replyInput.stance_summary || triageResult.short_reason || '',
      candidate_snippet: replyInput.candidate_snippet || ticket.event.content || '',
      context_notes: replyInput.context_notes || '',
      reply_objectives: Array.isArray(replyInput.reply_objectives) ? replyInput.reply_objectives : [],
    };
    const preferId = process.env.ORCH_REPLY_PROMPT_ID || undefined;
    return this.buildFromYamlUnified('reply', ticket, preferId, vars);
  }

  private static buildTriageFromYaml(ticket: Ticket): string {
    const vars = { candidate_snippet: ticket.event.content || '' };
    return this.buildFromYamlUnified('triage', ticket, undefined, vars);
  }

  /* ---------- 驗證（把解析＆欄位檢查拆開，兩者複用） ---------- */

  private static validateReplyObjectCore(obj: any, cap: number): string[] {
    const errors: string[] = [];

    if (typeof obj.reply !== 'string' || obj.reply.trim().length < 40) {
      errors.push('reply 字數不足 (至少 40 字)');
    }
    if (!Number.isFinite(obj.confidence) || obj.confidence < 0 || obj.confidence > 1) {
      errors.push('confidence 必須介於 0~1');
    }
    expectCitations(obj.citations, errors);
    expectArrayOfStrings(obj.hashtags, 'hashtags', errors);
    expectArrayOfStrings(obj.tone_tags, 'tone_tags', errors);

    if (typeof obj.needs_followup !== 'boolean') {
      errors.push('needs_followup 必須為布林值');
    }
    if (obj.needs_followup && (typeof obj.followup_notes !== 'string' || !obj.followup_notes.trim())) {
      errors.push('needs_followup=true 時必須提供 followup_notes');
    }
    if (obj.reply && obj.reply.length > cap) {
      errors.push(`reply 超過最大長度 ${cap}`);
    }
    return errors;
  }

  static validateReplyOutput(raw: string, ticket: Ticket): { valid: boolean; errors: string[]; parsed?: any } {
    const text = stripFences(raw);
    const parsed = safeParseJson(text);
    if (!parsed.ok) return { valid: false, errors: [parsed.error] };

    const cap = clampMaxChars(ticket?.constraints?.max_chars, PromptBuilder.DEFAULT_MAX_CHARS);
    const errors = this.validateReplyObjectCore(parsed.value, cap);
    return { valid: errors.length === 0, errors, parsed: parsed.value };
  }

  static validateReplyOutputMax(raw: string, maxChars: number): { valid: boolean; errors: string[]; parsed?: any } {
    const text = stripFences(raw);
    const parsed = safeParseJson(text);
    if (!parsed.ok) return { valid: false, errors: [parsed.error] };

    const cap = clampMaxChars(maxChars, PromptBuilder.DEFAULT_MAX_CHARS);
    const errors = this.validateReplyObjectCore(parsed.value, cap);
    return { valid: errors.length === 0, errors, parsed: parsed.value };
  }

  /* ---------- 其餘維持原行為（一般提示與輔助） ---------- */

  private static extractContext(ticket: Ticket): PromptContext {
    const threadSummary = this.buildThreadSummary(ticket);
    return {
      threadSummary,
      memorySnippets: [],
      constraints: {
        lang: ticket.constraints.lang || 'zh-tw',
        maxChars: ticket.constraints.max_chars || PromptBuilder.DEFAULT_MAX_CHARS,
        style: 'professional',
      },
    };
  }

  private static buildThreadSummary(ticket: Ticket): string {
    const e = ticket.event;
    return `討論串 ID: ${e.thread_id}
使用者: ${e.actor}
時間: ${new Date(e.timestamp).toLocaleString('zh-TW')}
問題: ${e.content}`;
  }

  private static buildFromContext(context: PromptContext): string {
    const { threadSummary, memorySnippets = [], constraints } = context;
    const availableChars = constraints.maxChars - PromptBuilder.PROMPT_OVERHEAD;
    const maxResponseChars = Math.max(50, availableChars);

    const memory =
      memorySnippets.length > 0 ? `\n相關記憶：\n${memorySnippets.join('\n')}\n` : '';
    const langText = constraints.lang === 'zh-tw' ? '使用繁體中文回覆' : `使用 ${constraints.lang} 回覆`;
    const styleText = getStyleInstruction(constraints.style);

    return `系統：你是企業社群小編，需要${langText}，${styleText}，回覆不超過 ${maxResponseChars} 字。

任務指引：
1. 直接回答使用者的問題或提供下一步建議
2. 如需澄清，附加一句可行的澄清問題
3. 若涉及時程或承諾，使用保守語句並標記需內部確認
4. 不可杜撰未核實的資訊
5. 保持禮貌和專業態度

輸入資訊：
${threadSummary}${memory}

請根據以上資訊產生適當的回覆：`;
  }

  static validateAndTrimResponse(response: string, maxChars: number): string {
    return response.length <= maxChars ? response : smartTrim(response, maxChars);
  }

  static validateResponse(
    response: string,
    constraints: { lang: string; maxChars: number }
  ): { valid: boolean; errors: string[] } {
    const errors: string[] = [];
    if (!response || !response.trim()) errors.push('回覆不能為空');
    if (response.length > constraints.maxChars)
      errors.push(`回覆超過最大長度限制 ${constraints.maxChars} 字`);

    if (constraints.lang === 'zh-tw') {
      if (!/[\u4e00-\u9fff]/.test(response)) errors.push('回覆應包含中文內容');
      if (/[务国际东华]/.test(response)) errors.push('回覆可能包含簡體字，請使用繁體中文');
    }

    const taboo = ['保證', '絕對', '立即', '馬上完成', '免費', '特價', '限時', '個人資料', '帳號', '密碼'];
    for (const k of taboo) if (response.includes(k)) errors.push(`回覆包含不建議使用的詞彙：${k}`);
    return { valid: errors.length === 0, errors };
  }

  static estimateTokens(prompt: string): number {
    const zh = (prompt.match(/[\u4e00-\u9fff]/g) || []).length;
    const en = (prompt.match(/[a-zA-Z]+/g) || []).length;
    const other = prompt.length - zh - en;
    return Math.ceil(zh * 1.5 + en * 1.3 + other * 0.5);
  }

  static buildTestPrompt(content: string, maxChars: number = 200): string {
    return `請用繁體中文回覆以下問題，不超過 ${maxChars} 字：

${content}

回覆：`;
  }
}

/* ────────────────────────────── 純函式輔助 ────────────────────────────── */

function isReplyTicket(t: Ticket): boolean {
  if (t.type !== 'DraftTicket') return false;
  return (
    t.flow_id === 'reply_zh_hant_v1' ||
    t.event.type === 'reply_request' ||
    t.event.type === 'reply_candidate'
  );
}
function isTriageTicket(t: Ticket): boolean {
  if (t.type !== 'DraftTicket') return false;
  return t.flow_id === 'triage_zh_hant_v1' || t.event.type === 'triage_candidate';
}
function getStyleInstruction(style?: string): string {
  switch (style) {
    case 'friendly': return '語氣友善親切';
    case 'formal':   return '語氣正式嚴謹';
    case 'casual':   return '語氣輕鬆自然';
    case 'professional':
    default:         return '語氣簡潔專業';
  }
}
function smartTrim(text: string, maxChars: number): string {
  if (text.length <= maxChars) return text;
  const target = maxChars - 3;
  const end1 = ['。', '？', '！', '：'];
  for (let i = target; i >= target * 0.8; i--) if (end1.includes((text as any)[i])) return text.slice(0, i + 1);
  const end2 = ['，', '；', '、'];
  for (let i = target; i >= target * 0.9; i--) if (end2.includes((text as any)[i])) return text.slice(0, i + 1) + '...';
  return text.slice(0, target) + '...';
}